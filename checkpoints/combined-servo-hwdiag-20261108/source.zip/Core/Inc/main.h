/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32h7xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdbool.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define LED_Pin GPIO_PIN_3
#define LED_GPIO_Port GPIOE
#define MOTOR_DIR_Pin GPIO_PIN_0
#define MOTOR_DIR_GPIO_Port GPIOA
#define MOTOR_PWM_Pin GPIO_PIN_1
#define MOTOR_PWM_GPIO_Port GPIOA
#define SVERO_PWM_Pin GPIO_PIN_2
#define SVERO_PWM_GPIO_Port GPIOA
#define LM5116_EN_Pin GPIO_PIN_0
#define LM5116_EN_GPIO_Port GPIOB
#define BEEP_Pin GPIO_PIN_11
#define BEEP_GPIO_Port GPIOD
#define KEY1_Pin GPIO_PIN_12
#define KEY1_GPIO_Port GPIOD
#define KEY2_Pin GPIO_PIN_13
#define KEY2_GPIO_Port GPIOD
#define KEY3_Pin GPIO_PIN_14
#define KEY3_GPIO_Port GPIOD
#define KEY4_Pin GPIO_PIN_15
#define KEY4_GPIO_Port GPIOD
#define KEY_EC_Pin GPIO_PIN_8
#define KEY_EC_GPIO_Port GPIOC
#define LCD_RST_Pin GPIO_PIN_0
#define LCD_RST_GPIO_Port GPIOD
#define LCD_DC_Pin GPIO_PIN_2
#define LCD_DC_GPIO_Port GPIOD
#define LCD_LED_Pin GPIO_PIN_4
#define LCD_LED_GPIO_Port GPIOD

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
