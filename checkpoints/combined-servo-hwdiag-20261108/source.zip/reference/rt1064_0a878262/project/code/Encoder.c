#include "encoder.h"

Encoder_Init Encoder;
extern float current_speed;
/*
********************************************************************************************************
*                                               ʾ������
*                                             EXAMPLE  CODE
*
*                             (c) Copyright 2021; SaiShu.Lcc.; Leo
*                                 ��Ȩ����[��������Ƽ����޹�˾]
*
*               The code is for internal use only, not for commercial transactions(��Դѧϰ,��������).
*               The code ADAPTS the corresponding hardware circuit board(����ʹ��CarDo�ǿذ�),
*               the specific details consult the professional(��ӭ��ϵ����).
*********************************************************************************************************
*/

/**
* @brief        ��������ʼ��
* @param
* @ref
* @author       Leo
* @note
**/
void ENCODER_Init(void)
{
  encoder_quad_init(QTIMER1_ENCODER1, QTIMER1_ENCODER1_CH1_C0, QTIMER1_ENCODER1_CH2_C1);
}


/**
* @brief        ������ת�ٲ���
* @param
* @ref
* @author       Leo
* @note
**/
void ENCODER_RevSample(void)
{
  motorStr.EncoderValue = -encoder_get_count(QTIMER1_ENCODER1);

  //����һ�μ���ֵ��Ӧ�ľ����10ms�ڵ��ٶ�	
  Encoder.Distance_Once[0] = (float)(motorStr.EncoderValue * PI * motorStr.DiameterWheel) / (motorStr.EncoderLine * motorStr.ReductionRatio);
  Encoder.Speed[0] = Encoder.Distance_Once[0] / 0.01f;

  Encoder.Distance[0] = Encoder.Distance[0] + Encoder.Distance_Once[0];
  encoder_clear_count(QTIMER1_ENCODER1);

  //    if(motorStr.EncoderValue > 32767)
  //        motorStr.EncoderValue = motorStr.EncoderValue - 65536;

  //		motorStr.EncoderValue = motorStr.EncoderValue*4.0f;


      //PID��������������
      // pidStr.vi_FeedBack = motorStr.EncoderValue;
  current_speed = motorStr.EncoderValue;

  //����ʵ���ٶ�	---		m/s
  //icarStr.SpeedFeedback = (float)(motorStr.EncoderValue * PI * motorStr.DiameterWheel)/ MOTOR_CONTROL_CYCLE / motorStr.EncoderLine / 4.0f / motorStr.ReductionRatio; //  m/s
  icarStr.SpeedFeedback = (float)(motorStr.EncoderValue * PI * motorStr.DiameterWheel) / MOTOR_CONTROL_CYCLE / motorStr.EncoderLine / motorStr.ReductionRatio; //  m/s


  if (icarStr.SpeedFeedback > 0 && icarStr.SpeedFeedback > icarStr.SpeedMaxRecords)
    icarStr.SpeedMaxRecords = icarStr.SpeedFeedback;

  else if (icarStr.SpeedFeedback < 0 && -icarStr.SpeedFeedback > icarStr.SpeedMaxRecords)
    icarStr.SpeedMaxRecords = -icarStr.SpeedFeedback;
}




